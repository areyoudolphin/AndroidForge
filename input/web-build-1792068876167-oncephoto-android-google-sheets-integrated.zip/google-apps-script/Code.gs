/** OncePhoto Google Apps Script backend (prototype; not independently audited).
 * Spreadsheet columns are created/extended automatically. Drive stores ciphertext only.
 */
const SHEET_NAME = 'Shares';
const HEADERS = ['id','fileId','saltB64','wrapIvB64','wrappedKeyB64','photoIvB64','expiresAt','status','revokeTokenHash','createdAt','activeCodeHash','codeExpiresAt','codeUsed'];
const MAX_CIPHERTEXT_BYTES = 3 * 1024 * 1024; // conservative Apps Script request/response limit

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(body.action || '');
    if (action === 'health') return json_({ok:true, service:'OncePhoto Apps Script', configured:!!getOwnerSecret_()});
    if (action === 'createPhoto') return json_(createPhoto_(body));
    if (action === 'newCode') {
      lock.waitLock(20000);
      try { return json_(newCode_(body)); } finally { lock.releaseLock(); }
    }
    if (action === 'open') {
      lock.waitLock(20000);
      try { return json_(openOnce_(body)); } finally { lock.releaseLock(); }
    }
    if (action === 'revoke') {
      lock.waitLock(20000);
      try { return json_(revoke_(body)); } finally { lock.releaseLock(); }
    }
    throw new Error('Unknown action');
  } catch (err) {
    return json_({ok:false, error:String(err && err.message || err)});
  }
}
function doGet() { return json_({ok:true, service:'OncePhoto Apps Script', hint:'POST JSON actions to this web app URL.'}); }
function createPhoto_(b) {
  requireOwner_(b.ownerSecret);
  const hours = validHours_(b.expiresHours);
  const ciphertext = String(b.ciphertextB64 || '');
  if (!ciphertext) throw new Error('Missing encrypted photo');
  const bytes = Utilities.base64Decode(ciphertext);
  if (bytes.length > MAX_CIPHERTEXT_BYTES) throw new Error('Encrypted photo exceeds 3 MB backend limit; choose a smaller/compressed image.');
  ['saltB64','wrapIvB64','wrappedKeyB64','photoIvB64'].forEach(k => { if (!b[k]) throw new Error('Missing '+k); });
  const id = randomHex_(16);
  const revokeToken = randomHex_(32);
  const expiresAt = Date.now() + hours * 3600000;
  const file = DriveApp.createFile(Utilities.newBlob(bytes, 'application/octet-stream', 'oncephoto-'+id+'.bin'));
  file.setDescription('OncePhoto encrypted ciphertext only. Do not manually share this file.');
  const sh = sheet_();
  sh.appendRow([id,file.getId(),b.saltB64,b.wrapIvB64,b.wrappedKeyB64,b.photoIvB64,expiresAt,'active',sha256_(revokeToken),Date.now(),'','',false]);
  return {ok:true, photoId:id, revokeToken:revokeToken, expiresAt:expiresAt};
}
function newCode_(b) {
  requireOwner_(b.ownerSecret);
  const row = findRow_(String(b.photoId || ''));
  if (!row) throw new Error('Photo not found');
  const sh = sheet_(); const values = row.values;
  if (values[7] !== 'active' || Number(values[6]) <= Date.now()) throw new Error('Photo is revoked or expired');
  const token = randomHex_(24);
  const expiresAt = Math.min(Number(values[6]), Date.now() + validHours_(b.expiresHours) * 3600000);
  // Replacing activeCodeHash invalidates any previous unused code.
  sh.getRange(row.index, 11, 1, 3).setValues([[sha256_(token), expiresAt, false]]);
  return {ok:true, code:String(values[0])+'.'+token, expiresAt:expiresAt};
}
function openOnce_(b) {
  const code = String(b.code || ''); const dot = code.indexOf('.');
  if (dot < 1) throw new Error('Invalid one-time code');
  const id = code.slice(0,dot), token = code.slice(dot+1);
  const row = findRow_(id); if (!row) throw new Error('Invalid or expired code');
  const v = row.values; const now = Date.now();
  if (v[7] !== 'active' || Number(v[6]) <= now) throw new Error('Photo revoked or expired');
  if (!v[10] || v[12] === true || String(v[10]) !== sha256_(token) || Number(v[11]) <= now) throw new Error('Code invalid, expired, or already used');
  // Mark consumed while holding script lock BEFORE returning ciphertext. Failed network transfer also consumes it (fail closed).
  sheet_().getRange(row.index, 11, 1, 3).setValues([['', Number(v[11]), true]]);
  const file = DriveApp.getFileById(String(v[1]));
  const blob = file.getBlob(); const bytes = blob.getBytes();
  if (bytes.length > MAX_CIPHERTEXT_BYTES) throw new Error('Stored encrypted photo exceeds response limit');
  return {ok:true, photoId:id, ciphertextB64:Utilities.base64Encode(bytes), saltB64:String(v[2]), wrapIvB64:String(v[3]), wrappedKeyB64:String(v[4]), photoIvB64:String(v[5]), expiresAt:Number(v[6])};
}
function revoke_(b) {
  requireOwner_(b.ownerSecret);
  const row = findRow_(String(b.photoId || '')); if (!row) throw new Error('Photo not found');
  const sh = sheet_(); sh.getRange(row.index,8).setValue('revoked'); sh.getRange(row.index,11,1,3).setValues([['','',true]]);
  try { DriveApp.getFileById(String(row.values[1])).setTrashed(true); } catch (e) {}
  return {ok:true, revoked:true};
}
function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Open Apps Script from the OncePhoto Auth spreadsheet (Extensions → Apps Script).');
  let sh = ss.getSheetByName(SHEET_NAME); if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) sh.appendRow(HEADERS);
  else {
    const existing = sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String);
    HEADERS.forEach(h => { if (existing.indexOf(h) < 0) { sh.getRange(1, sh.getLastColumn()+1).setValue(h); existing.push(h); } });
  }
  return sh;
}
function findRow_(id) {
  const sh = sheet_(); if (sh.getLastRow() < 2) return null;
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);
  const idCol = headers.indexOf('id')+1; if (!idCol) throw new Error('Sheet missing id header');
  const found = sh.getRange(2,idCol,sh.getLastRow()-1,1).createTextFinder(id).matchEntireCell(true).findNext();
  if (!found) return null;
  const values = sh.getRange(found.getRow(),1,1,sh.getLastColumn()).getValues()[0];
  const obj = {}; headers.forEach((h,i)=>obj[h]=values[i]);
  return {index:found.getRow(), values:[obj.id,obj.fileId,obj.saltB64,obj.wrapIvB64,obj.wrappedKeyB64,obj.photoIvB64,obj.expiresAt,obj.status,obj.revokeTokenHash,obj.createdAt,obj.activeCodeHash,obj.codeExpiresAt,obj.codeUsed]};
}
function requireOwner_(secret) { const expected = getOwnerSecret_(); if (!expected || !secret || !constantTimeEqual_(String(secret),expected)) throw new Error('Owner authentication failed'); }
function getOwnerSecret_() { return PropertiesService.getScriptProperties().getProperty('OWNER_SECRET') || ''; }
function validHours_(v) { const n = Number(v || 1); if ([1,6,24].indexOf(n)<0) throw new Error('Expiry must be 1, 6, or 24 hours'); return n; }
function randomHex_(n) {
  // Apps Script does not expose Web Crypto. Build tokens from UUIDs generated by Google's service.
  // Remove hyphens and concatenate fresh UUIDs until the requested length is reached.
  let out = '';
  while (out.length < n * 2) out += Utilities.getUuid().replace(/-/g, '').toLowerCase();
  return out.slice(0, n * 2);
}
function sha256_(s) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join(''); }
function constantTimeEqual_(a,b) { if (a.length!==b.length) return false; let diff=0; for(let i=0;i<a.length;i++) diff |= a.charCodeAt(i)^b.charCodeAt(i); return diff===0; }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
/** Run manually once from the Apps Script editor to create a random owner secret in Script Properties.
 * Then open Project Settings → Script properties and copy OWNER_SECRET into a private password manager.
 */
function initializeOwnerSecret() {
  const props = PropertiesService.getScriptProperties();
  if (props.getProperty('OWNER_SECRET')) throw new Error('OWNER_SECRET already exists; not replacing it.');
  const secret = randomHex_(48);
  props.setProperty('OWNER_SECRET',secret);
  Logger.log('OWNER_SECRET created. Open Project Settings → Script properties to copy it securely. Do not share it with recipients or put it in source code.');
}
