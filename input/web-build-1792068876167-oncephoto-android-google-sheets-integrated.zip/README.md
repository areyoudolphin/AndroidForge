# OncePhoto

See [README-GOOGLE-SHEETS.md](README-GOOGLE-SHEETS.md) for setup. This is source only; no compiled APK is included.
