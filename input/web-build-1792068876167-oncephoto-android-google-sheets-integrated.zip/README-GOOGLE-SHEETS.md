# OncePhoto — Google Sheets + Apps Script backend (source prototype)

**This is source code, not an APK. It has not been compiled or independently security-audited. Test only with non-sensitive images.** This version uses Google Sheets for authorization metadata and Google Drive for encrypted ciphertext. The server never receives the photo password or plaintext photo by design.

## Important limitations
- Google Apps Script is a prototype backend, not a hardened production service. It has quotas and request/response limits. This build conservatively limits encrypted images to 3 MiB.
- Once a one-time code is accepted, the server marks it used before sending ciphertext. A network failure or wrong password consumes the code; issue a new one.
- `FLAG_SECURE` blocks ordinary Android screenshots and many recording methods, not external cameras, rooted/compromised devices, or all extraction methods. A viewer can potentially preserve ciphertext and analyze the app; no app can guarantee “impossible to share.”
- The server's Drive file is private by default; do not manually share those files. Anyone with spreadsheet/script editor access is trusted with service metadata.
- The owner secret is a bearer credential. Keep it private. It is entered in the sender app and included in the HTTPS request body because Apps Script web apps do not expose arbitrary request headers to `doPost`.
- Not independently audited. Do not use for highly sensitive photos.

## A. Prepare Google Sheet
1. Open your `OncePhoto Auth` spreadsheet.
2. Rename the first tab to `Shares`.
3. Existing first-row headers are okay; the script extends missing columns automatically. It needs at least the headers from the previous instructions. Do not add sample data rows.

## B. Paste Apps Script
1. In that spreadsheet, choose **Extensions → Apps Script**.
2. Open `Code.gs`, replace its contents with `google-apps-script/Code.gs` from this ZIP.
3. Save.
4. In the function selector choose `initializeOwnerSecret`, press Run, and approve the Google permissions. Run it only once. It generates a random secret and stores it in Script Properties.
5. Open **Project Settings** (gear icon) → **Script properties**. Copy the `OWNER_SECRET` value into a password manager/private note. Never send it to the recipient or commit it to GitHub. Do not paste it into the source code.

## C. Deploy web app
1. Click **Deploy → New deployment**.
2. Select type **Web app**.
3. Description: `OncePhoto backend`.
4. Execute as: **Me**.
5. Who has access: **Anyone** (otherwise recipients cannot authenticate; the app still requires the owner secret for sender-only operations).
6. Click Deploy and approve prompts.
7. Copy the web app URL ending in `/exec`.

Public web access means anyone can send requests to the endpoint, but only the owner secret authorizes photo creation, new codes, and revocation. Keep the secret private. If the deployment UI does not offer “Anyone,” this approach cannot work with that account's policies.

## D. Set the API URL in Android source
Open `app/src/main/java/org/oncephoto/app/MainActivity.kt` and replace:

`https://script.google.com/macros/s/REPLACE_WITH_DEPLOYMENT_ID/exec`

with your actual deployment URL ending `/exec`. Save and build a new APK. The app source is not prebuilt; no APK is included because it has not been successfully compiled and tested.

## E. Build using GitHub Actions (no Android Studio needed)
1. Upload the contents of this ZIP to your existing GitHub repository `areyoudolphin/oncephoto`, replacing the old source files. Include `.github/workflows/android.yml`.
2. Commit/push to `main`, or open **Actions → Build OncePhoto APK → Run workflow**.
3. Wait for the workflow to finish. If successful, open the run and download artifact `oncephoto-debug-apk`; unzip it to get `app-debug.apk`.
4. Install only after reviewing/testing. This is a debug APK and not a Play Store release.

## F. Use it
**Sender:** online → choose photo → enter 12+ character photo password → enter `OWNER_SECRET` → choose expiry → Encrypt & upload photo. Send the one-time code and photo password through separate channels. The server returns the code; code is consumed on first successful server authorization attempt, before decryption. To allow another view, tap Generate new one-time code; the prior unused code is invalidated. Revoke last photo disables access and trashes the encrypted Drive file.

**Recipient:** online → enter code and photo password → Authenticate & view once. The server consumes the code before returning encrypted bytes. Wrong password/network interruption can still consume the code; generate a new code.

## API actions
Apps Script accepts JSON POST actions `createPhoto`, `newCode`, `open`, `revoke`, and `health`. `OWNER_SECRET` is required for sender operations, not for open. Sheet columns are extended automatically as needed.
