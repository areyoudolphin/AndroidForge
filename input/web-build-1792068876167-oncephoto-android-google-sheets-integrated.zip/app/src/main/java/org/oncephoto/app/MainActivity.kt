package org.oncephoto.app

import androidx.activity.ComponentActivity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

class MainActivity : ComponentActivity() {
    // Replace with the deployed Google Apps Script Web App URL ending in /exec.
    private val apiBase = "https://script.google.com/macros/s/AKfycbyfA9qpJq9MPvO-m3sc4TX7d1jFGKi9gnO3xQzqI5duqUmq_M74Kh1v7IFxVkr6tuLioA/exec"
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var image: ImageView
    private lateinit var codeInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var passwordCreate: EditText
    private lateinit var ownerSecretInput: EditText
    private lateinit var expiry: Spinner
    private var selectedBytes: ByteArray? = null
    private var lastPhotoId: String? = null
    private var lastCode: String? = null
    private var displayedBitmap: Bitmap? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) executor.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Could not read image")
                if (bytes.size > 2 * 1024 * 1024) throw IllegalArgumentException("Choose an image under 2 MB (Apps Script backend limit)")
                selectedBytes?.fill(0)
                selectedBytes = bytes
                runOnUiThread { status.text = "Photo selected (${bytes.size / 1024} KB). Enter owner secret and a strong photo password." }
            } catch (e: Exception) { showError(e.message ?: "Image read failed") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        lastPhotoId = getSharedPreferences("oncephoto", MODE_PRIVATE).getString("lastPhotoId", null)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24) }
        root.addView(TextView(this).apply { text = "OncePhoto"; textSize = 28f; setTextColor(0xff172033.toInt()) })
        root.addView(TextView(this).apply { text = "Encrypted one-time photo access · internet required"; textSize = 14f })
        status = TextView(this).apply {
            text = if (apiBase.contains("REPLACE_WITH")) "Setup required: deploy Google Apps Script and set its /exec URL in MainActivity.kt." else "Choose a photo to create a share, or enter a received code. Internet is required."
            setPadding(0, 18, 0, 14)
        }
        root.addView(status)
        root.addView(Button(this).apply { text = "Choose photo"; setOnClickListener { pickImage.launch("image/*") } })
        passwordCreate = EditText(this).apply { hint = "Photo password (12+ characters; share separately)"; inputType = 0x00000081 }
        root.addView(passwordCreate)
        ownerSecretInput = EditText(this).apply { hint = "Owner secret (Apps Script property OWNER_SECRET)"; inputType = 0x00000081 }
        root.addView(ownerSecretInput)
        expiry = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Expire in 1 hour", "Expire in 6 hours", "Expire in 24 hours"))
        }
        root.addView(expiry)
        root.addView(Button(this).apply { text = "Encrypt & upload photo"; setOnClickListener { createPhoto() } })
        root.addView(Button(this).apply { text = "Generate new one-time code"; setOnClickListener { generateNewCode() } })
        root.addView(Button(this).apply { text = "Copy latest code"; setOnClickListener { copyLatestCode() } })
        root.addView(Button(this).apply { text = "Revoke last photo"; setOnClickListener { revokePhoto() } })
        root.addView(TextView(this).apply { text = "Open a received photo"; textSize = 18f; setPadding(0, 24, 0, 4) })
        codeInput = EditText(this).apply { hint = "One-time code (photoId.token)"; inputType = 0x00000000 }
        root.addView(codeInput)
        passwordInput = EditText(this).apply { hint = "Photo password"; inputType = 0x00000081 }
        root.addView(passwordInput)
        root.addView(Button(this).apply { text = "Authenticate & view once"; setOnClickListener { openPhoto() } })
        image = ImageView(this).apply { adjustViewBounds = true; maxHeight = 1200; setPadding(0, 12, 0, 12) }
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Close photo now"; setOnClickListener { clearViewer("Photo closed and temporary display cleared.") } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requireApi(): Boolean {
        if (apiBase.contains("REPLACE_WITH")) { toast("Setup required: deploy Apps Script and set apiBase in MainActivity.kt"); return false }
        return true
    }

    private fun expiryHours() = when (expiry.selectedItemPosition) { 0 -> 1; 1 -> 6; else -> 24 }

    private fun createPhoto() {
        val bytes = selectedBytes ?: return toast("Choose a photo first")
        val password = passwordCreate.text.toString()
        val ownerSecret = ownerSecretInput.text.toString()
        if (password.length < 12) return toast("Use a photo password of at least 12 characters")
        if (ownerSecret.length < 32) return toast("Enter the owner secret configured in Apps Script (at least 32 characters)")
        if (!requireApi()) return
        status.text = "Encrypting locally and uploading encrypted bytes…"
        val hours = expiryHours()
        executor.execute {
            try {
                val random = SecureRandom()
                val contentKey = ByteArray(32).also(random::nextBytes)
                val photoIv = ByteArray(12).also(random::nextBytes)
                val photoCipher = aesGcm(Cipher.ENCRYPT_MODE, contentKey, photoIv, bytes)
                val salt = ByteArray(16).also(random::nextBytes)
                val wrapIv = ByteArray(12).also(random::nextBytes)
                val passwordKey = derivePasswordKey(password, salt)
                val wrappedKey = aesGcm(Cipher.ENCRYPT_MODE, passwordKey, wrapIv, contentKey)
                contentKey.fill(0); passwordKey.fill(0)
                val payload = JSONObject().apply {
                    put("ciphertextB64", b64(photoCipher)); put("saltB64", b64(salt)); put("wrapIvB64", b64(wrapIv))
                    put("wrappedKeyB64", b64(wrappedKey)); put("photoIvB64", b64(photoIv)); put("expiresHours", hours)
                }
                payload.put("ownerSecret", ownerSecret)
                val created = request("/api/photos", "POST", payload.toString(), ownerSecret)
                val photoId = created.getString("photoId")
                val codeResponse = request("/api/photos/$photoId/codes", "POST", JSONObject().put("expiresHours", hours).toString(), ownerSecret)
                val code = codeResponse.getString("code")
                lastPhotoId = photoId; lastCode = code
                getSharedPreferences("oncephoto", MODE_PRIVATE).edit().putString("lastPhotoId", photoId).apply()
                runOnUiThread {
                    codeInput.setText(code)
                    status.text = "Encrypted photo uploaded. Send the ONE-TIME CODE and photo password separately. Save the photo ID for future codes: $photoId\nCode expires at ${codeResponse.getLong("expiresAt")}. Generating a new code invalidates this code."
                }
                bytes.fill(0); selectedBytes = null; photoCipher.fill(0); wrappedKey.fill(0)
            } catch (e: Exception) { showError(e.message ?: "Photo creation failed") }
        }
    }

    private fun generateNewCode() {
        val photoId = lastPhotoId ?: getSharedPreferences("oncephoto", MODE_PRIVATE).getString("lastPhotoId", null)
            ?: return toast("Create a photo first on this device")
        val ownerSecret = ownerSecretInput.text.toString()
        if (ownerSecret.length < 32) return toast("Enter your owner secret")
        if (!requireApi()) return
        status.text = "Requesting a fresh code…"
        executor.execute {
            try {
                val response = request("/api/photos/$photoId/codes", "POST", JSONObject().put("expiresHours", expiryHours()).put("ownerSecret", ownerSecret).toString(), ownerSecret)
                lastCode = response.getString("code")
                runOnUiThread { codeInput.setText(lastCode); status.text = "New code generated. All older unused codes for this photo are now invalid. Code: $lastCode" }
            } catch (e: Exception) { showError(e.message ?: "Could not generate a code") }
        }
    }

    private fun copyLatestCode() {
        val code = lastCode ?: codeInput.text.toString().trim().takeIf { it.contains('.') }
            ?: return toast("Create a photo or generate a code first")
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("OncePhoto one-time code", code))
        toast("Code copied. Send it separately from the photo password.")
    }

    private fun openPhoto() {
        val code = codeInput.text.toString().trim()
        val password = passwordInput.text.toString()
        if (code.isBlank() || password.isBlank()) return toast("Enter one-time code and photo password")
        if (!requireApi()) return
        clearViewer(null)
        status.text = "Authenticating online and consuming one-time code…"
        executor.execute {
            try {
                val response = request("/api/open", "POST", JSONObject().put("code", code).toString())
                val salt = unb64(response.getString("saltB64")); val wrapIv = unb64(response.getString("wrapIvB64"))
                val wrapped = unb64(response.getString("wrappedKeyB64")); val photoIv = unb64(response.getString("photoIvB64"))
                val ciphertext = unb64(response.getString("ciphertextB64"))
                val passwordKey = derivePasswordKey(password, salt)
                val contentKey = aesGcm(Cipher.DECRYPT_MODE, passwordKey, wrapIv, wrapped)
                passwordKey.fill(0)
                val plaintext = aesGcm(Cipher.DECRYPT_MODE, contentKey, photoIv, ciphertext)
                contentKey.fill(0); ciphertext.fill(0); wrapped.fill(0)
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(plaintext, 0, plaintext.size, opts)
                var sample = 1
                while (opts.outWidth / sample > 1600 || opts.outHeight / sample > 1600) sample *= 2
                val decoded = BitmapFactory.decodeByteArray(plaintext, 0, plaintext.size, BitmapFactory.Options().apply { inSampleSize = sample })
                plaintext.fill(0)
                if (decoded == null) throw IllegalStateException("Could not decode photo")
                runOnUiThread {
                    displayedBitmap = decoded
                    image.setImageBitmap(decoded)
                    status.text = "Authorized online. This code is consumed and cannot be reused. Close the photo to clear the display. If the password was wrong, ask the sender for a new code."
                }
            } catch (e: Exception) {
                showError("Could not open photo. The code may be used/expired, internet unavailable, or password incorrect. A code is consumed before decryption; request a new one if needed. (${e.message ?: "error"})")
            }
        }
    }

    private fun revokePhoto() {
        val id = lastPhotoId ?: return toast("No photo ID saved on this device")
        val ownerSecret = ownerSecretInput.text.toString()
        if (ownerSecret.length < 32) return toast("Enter your owner secret")
        if (!requireApi()) return
        executor.execute {
            try {
                request("/api/photos/$id", "DELETE", JSONObject().put("ownerSecret", ownerSecret).toString(), ownerSecret)
                lastPhotoId = null; lastCode = null
                getSharedPreferences("oncephoto", MODE_PRIVATE).edit().remove("lastPhotoId").apply()
                runOnUiThread { status.text = "Photo revoked and encrypted object deleted from server storage." }
            } catch (e: Exception) { showError(e.message ?: "Revocation failed") }
        }
    }

    private fun derivePasswordKey(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 600_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    private fun aesGcm(mode: Int, key: ByteArray, iv: ByteArray, input: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(input)
    }

    private fun request(path: String, method: String, body: String, ownerSecret: String? = null): JSONObject {
        val input = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        if (ownerSecret != null) input.put("ownerSecret", ownerSecret)
        val action = when {
            path == "/api/photos" && method == "POST" -> "createPhoto"
            path == "/api/open" && method == "POST" -> "open"
            path.matches(Regex("/api/photos/[^/]+/codes")) && method == "POST" -> "newCode"
            path.matches(Regex("/api/photos/[^/]+")) && method == "DELETE" -> "revoke"
            path == "/api/health" -> "health"
            else -> throw IllegalArgumentException("Unsupported API operation")
        }
        if (action == "newCode" || action == "revoke") {
            val parts = path.split("/")
            input.put("photoId", parts[3])
        }
        input.put("action", action)
        val conn = (URL(apiBase).openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 60000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Cache-Control", "no-store")
            conn.doOutput = true
            conn.outputStream.use { it.write(input.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val result = try { JSONObject(text) } catch (_: Exception) { throw IllegalStateException("Server returned a non-JSON response (HTTP $code). Check Apps Script deployment URL/access.") }
            if (code !in 200..299 || result.optBoolean("ok", true).not()) {
                val detail = result.optString("error", "Server HTTP $code")
                throw IllegalStateException("$detail")
            }
            return result
        } finally { conn.disconnect() }
    }

    private fun clearViewer(message: String?) {
        image.setImageDrawable(null)
        displayedBitmap?.recycle()
        displayedBitmap = null
        if (message != null) status.text = message
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.DEFAULT)
    private fun showError(message: String) { runOnUiThread { status.text = message } }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    override fun onStop() { clearViewer(null); super.onStop() }
    override fun onDestroy() { clearViewer(null); selectedBytes?.fill(0); selectedBytes = null; executor.shutdownNow(); super.onDestroy() }
}
