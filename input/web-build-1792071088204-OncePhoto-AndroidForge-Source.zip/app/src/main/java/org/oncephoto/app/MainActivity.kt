package org.oncephoto.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.text.InputType
import android.util.Base64
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : ComponentActivity() {
    private val apiBase = "https://script.google.com/macros/s/AKfycbzr1Gk42O3rmuhUfAjS9Iga-VhWKXzG9Ngd8wgSiMHICnHpSRKatPvRhjUVn6wpk7qBWw/exec"
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var codeInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var passwordCreate: EditText
    private lateinit var ownerSecretInput: EditText
    private lateinit var image: ImageView
    private lateinit var expiry: Spinner
    private var selectedPhoto: Uri? = null
    private var lastPhotoId: String? = null
    private var lastCode: String? = null
    private var displayedBitmap: Bitmap? = null
    private var pending: PendingShare? = null

    private data class PendingShare(
        val photoUri: Uri,
        val photoId: String,
        val contentKey: ByteArray,
        val photoIv: ByteArray,
        val expiresHours: Int,
        val ownerSecret: String
    )

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedPhoto = uri
            status.text = "Photo selected. It will be encrypted on this phone and saved as a .oncephoto file."
        }
    }
    private val saveEncryptedFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val p = pending
        if (uri == null || p == null) {
            p?.contentKey?.fill(0)
            pending = null
            status.text = "Saving cancelled. No photo was uploaded. The unused share record will expire."
            return@registerForActivityResult
        }
        executor.execute {
            try {
                contentResolver.openInputStream(p.photoUri).use { source ->
                    if (source == null) throw IOException("Could not read selected photo")
                    contentResolver.openOutputStream(uri, "w").use { raw ->
                        if (raw == null) throw IOException("Could not create encrypted file")
                        DataOutputStream(BufferedOutputStream(raw)).use { header ->
                            val idBytes = p.photoId.toByteArray(Charsets.UTF_8)
                            header.write(byteArrayOf('O'.code.toByte(), 'N'.code.toByte(), 'C'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte()))
                            header.writeShort(idBytes.size)
                            header.write(idBytes)
                            header.writeByte(p.photoIv.size)
                            header.write(p.photoIv)
                            header.flush()
                            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(p.contentKey, "AES"), GCMParameterSpec(128, p.photoIv))
                            CipherOutputStream(header, cipher).use { encryptedOut ->
                                val buffer = ByteArray(64 * 1024)
                                while (true) {
                                    val n = source.read(buffer)
                                    if (n < 0) break
                                    encryptedOut.write(buffer, 0, n)
                                }
                                buffer.fill(0)
                            }
                        }
                    }
                }
                p.contentKey.fill(0)
                val codeResult = request(JSONObject().put("action", "newCode").put("ownerSecret", p.ownerSecret)
                    .put("photoId", p.photoId).put("codeExpiresHours", p.expiresHours).toString())
                lastPhotoId = p.photoId
                lastCode = codeResult.getString("code")
                getSharedPreferences("oncephoto", MODE_PRIVATE).edit()
                    .putString("lastPhotoId", p.photoId)
                    .putString("lastRevokeToken", getSharedPreferences("oncephoto", MODE_PRIVATE).getString("lastRevokeToken", ""))
                    .apply()
                runOnUiThread {
                    codeInput.setText(lastCode)
                    status.text = "Encrypted file saved locally. Send the .oncephoto file and the one-time code/password separately. Google received only key-wrapping metadata, never the photo. Code: $lastCode"
                    pending = null
                }
            } catch (e: Exception) {
                p.contentKey.fill(0)
                pending = null
                showError("Could not save encrypted file: ${e.message ?: "error"}. No photo bytes are uploaded.")
            }
        }
    }
    private val pickEncryptedFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openEncryptedFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE)
        lastPhotoId = prefs.getString("lastPhotoId", null)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24) }
        root.addView(TextView(this).apply { text = "OncePhoto"; textSize = 28f; setTextColor(0xff172033.toInt()) })
        root.addView(TextView(this).apply { text = "Local encryption · Google authentication only"; textSize = 14f })
        status = TextView(this).apply { text = "Choose a photo to encrypt locally. Photo bytes are never sent to Google."; setPadding(0, 18, 0, 14) }
        root.addView(status)
        root.addView(Button(this).apply { text = "Choose original photo"; setOnClickListener { pickPhoto.launch("image/*") } })
        passwordCreate = EditText(this).apply { hint = "Photo password (12+ characters; share separately)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        root.addView(passwordCreate)
        ownerSecretInput = EditText(this).apply { hint = "Owner secret (Apps Script OWNER_SECRET)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        root.addView(ownerSecretInput)
        expiry = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Share expires in 1 hour", "Share expires in 6 hours", "Share expires in 24 hours")) }
        root.addView(expiry)
        root.addView(Button(this).apply { text = "Encrypt & save local file"; setOnClickListener { beginCreate() } })
        root.addView(Button(this).apply { text = "Generate new one-time code"; setOnClickListener { generateNewCode() } })
        root.addView(Button(this).apply { text = "Copy latest code"; setOnClickListener { copyLatestCode() } })
        root.addView(Button(this).apply { text = "Revoke last share"; setOnClickListener { revokeShare() } })
        root.addView(TextView(this).apply { text = "Receive a photo"; textSize = 18f; setPadding(0, 24, 0, 4) })
        root.addView(Button(this).apply { text = "Choose received .oncephoto file"; setOnClickListener { pickEncryptedFile.launch(arrayOf("*/*")) } })
        codeInput = EditText(this).apply { hint = "One-time code (photoId.token)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS; isSingleLine = true; isFocusable = true; isFocusableInTouchMode = true }
        root.addView(codeInput)
        passwordInput = EditText(this).apply { hint = "Separate photo password"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        root.addView(passwordInput)
        root.addView(Button(this).apply { text = "Authenticate & view once"; setOnClickListener { val uri = receiveUri ?: return@setOnClickListener toast("Choose the received encrypted file first"); openEncryptedFile(uri) } })
        image = ImageView(this).apply { adjustViewBounds = true; maxHeight = 1200; setPadding(0, 12, 0, 12) }
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Close photo now"; setOnClickListener { clearViewer("Photo closed and display memory cleared.") } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private var receiveUri: Uri? = null
    private fun expiryHours() = when (expiry.selectedItemPosition) { 0 -> 1; 1 -> 6; else -> 24 }

    private fun beginCreate() {
        val photo = selectedPhoto ?: return toast("Choose a photo first")
        val password = passwordCreate.text.toString()
        val owner = ownerSecretInput.text.toString()
        if (password.length < 12) return toast("Use a password of at least 12 characters")
        if (owner.length < 32) return toast("Enter the Apps Script owner secret")
        val hours = expiryHours()
        status.text = "Preparing encryption metadata. Photo bytes stay on this phone…"
        executor.execute {
            try {
                val random = SecureRandom()
                val contentKey = ByteArray(32).also(random::nextBytes)
                val photoIv = ByteArray(12).also(random::nextBytes)
                val salt = ByteArray(16).also(random::nextBytes)
                val wrapIv = ByteArray(12).also(random::nextBytes)
                val passwordKey = derivePasswordKey(password, salt)
                val wrappedKey = aesGcm(Cipher.ENCRYPT_MODE, passwordKey, wrapIv, contentKey)
                passwordKey.fill(0)
                val registered = request(JSONObject().put("action", "registerPhoto")
                    .put("ownerSecret", owner).put("saltB64", b64(salt)).put("wrapIvB64", b64(wrapIv))
                    .put("wrappedKeyB64", b64(wrappedKey)).put("expiresHours", hours).toString())
                wrappedKey.fill(0)
                val id = registered.getString("photoId")
                val revokeToken = registered.getString("revokeToken")
                getSharedPreferences("oncephoto", MODE_PRIVATE).edit().putString("lastPhotoId", id).putString("lastRevokeToken", revokeToken).apply()
                pending = PendingShare(photo, id, contentKey, photoIv, hours, owner)
                runOnUiThread {
                    status.text = "Choose where to save the encrypted file. The photo itself is not uploaded."
                    saveEncryptedFile.launch("OncePhoto-$id.oncephoto")
                }
            } catch (e: Exception) { showError("Could not prepare share: ${e.message ?: "error"}") }
        }
    }

    private fun generateNewCode() {
        val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE)
        val id = lastPhotoId ?: prefs.getString("lastPhotoId", null) ?: return toast("Create a share first")
        val owner = ownerSecretInput.text.toString()
        if (owner.length < 32) return toast("Enter your owner secret")
        executor.execute {
            try {
                val r = request(JSONObject().put("action", "newCode").put("ownerSecret", owner).put("photoId", id).put("codeExpiresHours", expiryHours()).toString())
                lastCode = r.getString("code")
                runOnUiThread { codeInput.setText(lastCode); status.text = "New one-time code generated: $lastCode. Send it separately from the password." }
            } catch (e: Exception) { showError(e.message ?: "Could not generate code") }
        }
    }

    private fun copyLatestCode() {
        val code = lastCode ?: codeInput.text.toString().trim().takeIf { it.contains('.') } ?: return toast("Generate a code first")
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("OncePhoto code", code))
        toast("Code copied. Send it separately from the photo password.")
    }

    private fun revokeShare() {
        val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE)
        val id = lastPhotoId ?: prefs.getString("lastPhotoId", null) ?: return toast("No share to revoke")
        val token = prefs.getString("lastRevokeToken", null) ?: return toast("Revocation token missing; this share cannot be revoked from this installation")
        val owner = ownerSecretInput.text.toString()
        if (owner.length < 32) return toast("Enter your owner secret")
        executor.execute {
            try {
                request(JSONObject().put("action", "revoke").put("ownerSecret", owner).put("photoId", id).put("revokeToken", token).toString())
                prefs.edit().remove("lastPhotoId").remove("lastRevokeToken").apply()
                lastPhotoId = null; lastCode = null
                runOnUiThread { status.text = "Share revoked. Future code attempts will be rejected." }
            } catch (e: Exception) { showError(e.message ?: "Revocation failed") }
        }
    }

    private fun openEncryptedFile(uri: Uri) {
        receiveUri = uri
        val code = codeInput.text.toString().trim()
        val password = passwordInput.text.toString()
        if (code.isBlank() || password.isBlank()) return toast("Enter the one-time code and password")
        val codeId = code.substringBefore('.', "")
        clearViewer(null)
        status.text = "Checking encrypted file and authenticating online…"
        executor.execute {
            var contentKey: ByteArray? = null
            var plainFile: File? = null
            try {
                val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open encrypted file")
                val header = DataInputStream(BufferedInputStream(input))
                val magic = ByteArray(5); header.readFully(magic)
                if (!magic.contentEquals(byteArrayOf(79, 78, 67, 80, 49))) throw IOException("Not a valid OncePhoto file")
                val idLen = header.readUnsignedShort()
                if (idLen !in 1..128) throw IOException("Invalid file header")
                val idBytes = ByteArray(idLen); header.readFully(idBytes)
                val fileId = String(idBytes, Charsets.UTF_8)
                val ivLen = header.readUnsignedByte()
                if (ivLen != 12) throw IOException("Invalid encryption header")
                val photoIv = ByteArray(ivLen); header.readFully(photoIv)
                if (fileId != codeId) { header.close(); throw IOException("The code does not match this encrypted file") }
                val auth = request(JSONObject().put("action", "open").put("code", code).toString())
                if (auth.getString("photoId") != fileId) { header.close(); throw IOException("Server returned a different share") }
                val salt = unb64(auth.getString("saltB64")); val wrapIv = unb64(auth.getString("wrapIvB64")); val wrapped = unb64(auth.getString("wrappedKeyB64"))
                val passwordKey = derivePasswordKey(password, salt)
                contentKey = aesGcm(Cipher.DECRYPT_MODE, passwordKey, wrapIv, wrapped)
                passwordKey.fill(0); wrapped.fill(0)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(contentKey, "AES"), GCMParameterSpec(128, photoIv))
                plainFile = File.createTempFile("oncephoto-", ".tmp", cacheDir)
                CipherInputStream(header, cipher).use { encryptedIn -> FileOutputStream(plainFile).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) { val n = encryptedIn.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
                    buffer.fill(0)
                } }
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(plainFile.absolutePath, opts)
                if (opts.outWidth <= 0 || opts.outHeight <= 0) throw IOException("Decrypted data is not a supported image")
                var sample = 1
                while (opts.outWidth / sample > 1800 || opts.outHeight / sample > 1800) sample *= 2
                val bitmap = BitmapFactory.decodeFile(plainFile.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: throw IOException("Could not display image")
                runOnUiThread { displayedBitmap = bitmap; image.setImageBitmap(bitmap); status.text = "Authenticated. This code has been consumed. Close the photo to clear the display." }
            } catch (e: Exception) {
                showError("Could not open photo: ${e.message ?: "error"}. A code may be consumed even if the password was wrong; ask the sender for a new code.")
            } finally {
                contentKey?.fill(0)
                try { plainFile?.delete() } catch (_: Exception) {}
            }
        }
    }

    private fun derivePasswordKey(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 600_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    private fun aesGcm(mode: Int, key: ByteArray, iv: ByteArray, input: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(input)
    }

    private fun request(body: String): JSONObject {
        val conn = URL(apiBase).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Cache-Control", "no-store")
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val result = try { JSONObject(text) } catch (_: Exception) { throw IOException("Server returned non-JSON (HTTP $code)") }
            if (code !in 200..299 || !result.optBoolean("ok", false)) throw IOException(result.optString("error", "Server error HTTP $code"))
            return result
        } finally { conn.disconnect() }
    }

    private fun clearViewer(message: String?) {
        image.setImageDrawable(null)
        displayedBitmap?.recycle(); displayedBitmap = null
        if (message != null) status.text = message
    }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.DEFAULT)
    private fun showError(message: String) { runOnUiThread { status.text = message } }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    override fun onStop() { clearViewer(null); super.onStop() }
    override fun onDestroy() { clearViewer(null); pending?.contentKey?.fill(0); executor.shutdownNow(); super.onDestroy() }
}
