const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "access-control-allow-origin": "*", "access-control-allow-methods": "POST, DELETE, OPTIONS", "access-control-allow-headers": "content-type" } });
const randomId = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, "0")).join("");

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-methods": "POST, DELETE, OPTIONS", "access-control-allow-headers": "content-type" } });
    try {
      if (url.pathname === "/api/share" && request.method === "POST") {
        const body = await request.json();
        for (const key of ["ciphertextB64", "saltB64", "wrapIvB64", "wrappedKeyB64", "photoIvB64"]) if (typeof body[key] !== "string") return json({ error: `Missing ${key}` }, 400);
        const hours = Number(body.expiresHours);
        if (![1, 6, 24].includes(hours)) return json({ error: "expiresHours must be 1, 6, or 24" }, 400);
        const binary = Uint8Array.from(atob(body.ciphertextB64), c => c.charCodeAt(0));
        if (binary.length < 17 || binary.length > 8 * 1024 * 1024 + 16) return json({ error: "Encrypted image must be under 8 MB" }, 413);
        const id = randomId(); const revokeToken = randomId(); const expiresAt = Date.now() + hours * 3600000;
        await env.CIPHERTEXT.put(id, binary, { httpMetadata: { contentType: "application/octet-stream" }, customMetadata: { expiresAt: String(expiresAt) } });
        const stub = env.SHARES.get(env.SHARES.idFromName(id));
        await stub.fetch("https://share-store/create", { method: "POST", body: JSON.stringify({ id, saltB64: body.saltB64, wrapIvB64: body.wrapIvB64, wrappedKeyB64: body.wrappedKeyB64, photoIvB64: body.photoIvB64, expiresAt, revokeToken }) });
        return json({ id, expiresAt, revokeToken });
      }
      if (url.pathname === "/api/open" && request.method === "POST") {
        const { id } = await request.json();
        if (typeof id !== "string" || !/^[a-f0-9]{32}$/.test(id)) return json({ error: "Invalid share code" }, 400);
        const stub = env.SHARES.get(env.SHARES.idFromName(id));
        const consumed = await stub.fetch("https://share-store/take", { method: "POST" });
        if (!consumed.ok) { await env.CIPHERTEXT.delete(id); return json({ error: "Share expired, revoked, or already opened" }, 410); }
        const meta = await consumed.json();
        const obj = await env.CIPHERTEXT.get(id);
        if (!obj) return json({ error: "Encrypted photo is unavailable" }, 410);
        const bytes = new Uint8Array(await obj.arrayBuffer());
        await env.CIPHERTEXT.delete(id);
        let binary = ""; for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        return json({ ...meta, ciphertextB64: btoa(binary) });
      }
      const match = url.pathname.match(/^\/api\/share\/([a-f0-9]{32})$/);
      if (match && request.method === "DELETE") {
        const { revokeToken } = await request.json();
        const stub = env.SHARES.get(env.SHARES.idFromName(match[1]));
        const res = await stub.fetch("https://share-store/revoke", { method: "POST", body: JSON.stringify({ revokeToken }) });
        if (!res.ok) return json({ error: "Invalid token or share already consumed" }, 403);
        await env.CIPHERTEXT.delete(match[1]); return json({ revoked: true });
      }
      return json({ error: "Not found" }, 404);
    } catch (e) { return json({ error: "Request failed", detail: String(e?.message || e) }, 500); }
  }
};

export class ShareStore {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === "/create" && request.method === "POST") {
      const data = await request.json();
      await this.ctx.storage.put("meta", data);
      return new Response("ok");
    }
    if (path === "/take" && request.method === "POST") {
      // Durable Object requests execute serially; delete metadata before returning it.
      const data = await this.ctx.storage.get("meta");
      if (!data || data.expiresAt <= Date.now()) { await this.ctx.storage.delete("meta"); return new Response("gone", { status: 410 }); }
      await this.ctx.storage.delete("meta");
      const { id, saltB64, wrapIvB64, wrappedKeyB64, photoIvB64, expiresAt } = data;
      return Response.json({ id, saltB64, wrapIvB64, wrappedKeyB64, photoIvB64, expiresAt });
    }
    if (path === "/revoke" && request.method === "POST") {
      const { revokeToken } = await request.json(); const data = await this.ctx.storage.get("meta");
      if (!data || !revokeToken || data.revokeToken !== revokeToken) return new Response("forbidden", { status: 403 });
      await this.ctx.storage.delete("meta"); return new Response("ok");
    }
    return new Response("not found", { status: 404 });
  }
}
