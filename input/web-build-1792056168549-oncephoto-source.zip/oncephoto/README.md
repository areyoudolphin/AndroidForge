# OncePhoto (prototype)

Open-source Android prototype for password-wrapped, one-time photo sharing.

## Security model
- The Android client generates a random AES-256-GCM content key and encrypts the photo locally.
- A password-derived key (PBKDF2-HMAC-SHA256, 600,000 iterations) wraps the content key locally. The password is never sent to the server.
- Cloudflare Worker stores ciphertext in R2 and stores one-time metadata in a Durable Object. The Durable Object atomically consumes the share metadata.
- The Android viewer uses `FLAG_SECURE`, disables backup, and avoids writing decrypted plaintext to disk.

## Important limitations
This is a security-sensitive prototype, not audited software. A one-time server response cannot stop a recipient from copying decrypted bytes, extracting memory on a compromised/rooted device, or photographing the display externally. `FLAG_SECURE` blocks ordinary Android screenshots and capture paths, not every possible capture. The server can delete/expire ciphertext but cannot prove the recipient actually viewed it. If a recipient saves the password and encrypted payload before the first open, they may be able to attempt decryption later if they also obtain the wrapped key; the one-time service prevents ordinary second retrieval, not malicious retention of all materials. Test only with non-sensitive photos until reviewed.

## Files
- `app/`: Android Kotlin app
- `worker/`: Cloudflare Worker + Durable Object + R2

## Backend deployment (Cloudflare)
Requirements: Cloudflare account, Node.js/npm in Termux, Wrangler.

1. In Termux, install Node.js: `pkg install nodejs-lts`.
2. From `worker/`, run `npm install` then `npx wrangler login`.
3. Create the R2 bucket: `npx wrangler r2 bucket create oncephoto-ciphertext`.
4. Deploy: `npx wrangler deploy`.
5. Copy the deployed Worker URL. In Android `MainActivity.kt`, replace `https://REPLACE_WITH_YOUR_WORKER.workers.dev` with that URL.
6. Rebuild the app after changing the URL.

Cloudflare may require enabling R2 and accepting its terms. Review current pricing/limits before using it. The Durable Object binding uses SQLite storage and requires a recent Wrangler version.

## Build notes for Termux
Native Android builds on an Android/ARM64 phone are not officially supported by Google's standard Android SDK tooling; a Termux-only build may fail depending on SDK/build-tools availability. This project uses standard Gradle/Android Gradle Plugin and needs JDK 17+, Android SDK platform 35 and build-tools 35.0.0. If your Termux environment has a compatible Gradle + SDK, from the project root run:

```sh
pkg update
pkg install openjdk-17 gradle aapt apksigner
# Configure ANDROID_HOME to a working Android SDK containing platforms/android-35 and build-tools/35.0.0
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/35.0.0"
gradle --no-daemon assembleDebug
```

The above commands are a best-effort path, not a guarantee: standard Google SDK packages may not run natively under Termux. Do not install random prebuilt SDK bundles. If local compilation fails, the source remains portable to a Linux ARM64/amd64 build machine or a trusted cloud CI runner, but that would no longer be a Termux-only build.

## API behavior
- `POST /api/share`: JSON `{ciphertextB64, saltB64, wrapIvB64, wrappedKeyB64, photoIvB64, expiresHours}`. Returns `{id, expiresAt}`.
- `POST /api/open`: JSON `{id}`. Atomically consumes the share and returns encrypted bytes and wrapping metadata once.
- `DELETE /api/share/:id`: sender revocation (requires the revoke token returned on creation).

The initial prototype's revocation token is returned to the sender only and should be kept private.
