package org.oncephoto.app

import androidx.activity.ComponentActivity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

class MainActivity : ComponentActivity() {
    private val apiBase = "https://REPLACE_WITH_YOUR_WORKER.workers.dev"
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var image: ImageView
    private lateinit var codeInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var passwordCreate: EditText
    private lateinit var expiry: Spinner
    private var selectedBytes: ByteArray? = null
    private var revokeToken: String? = null
    private var currentShareId: String? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) executor.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Could not read image")
                if (bytes.size > 8 * 1024 * 1024) throw IllegalArgumentException("Choose an image under 8 MB")
                selectedBytes = bytes
                runOnUiThread { status.text = "Photo selected (${bytes.size / 1024} KB). Enter a strong password, then create link." }
            } catch (e: Exception) { showError(e.message ?: "Image read failed") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24) }
        root.addView(TextView(this).apply { text = "OncePhoto"; textSize = 28f; setTextColor(0xff172033.toInt()) })
        root.addView(TextView(this).apply { text = "Encrypted one-time photo sharing prototype"; textSize = 14f })
        status = TextView(this).apply { text = "Choose a photo to create a one-time share, or open a share code."; setPadding(0, 18, 0, 14) }
        root.addView(status)
        val pick = Button(this).apply { text = "Choose photo"; setOnClickListener { pickImage.launch("image/*") } }
        root.addView(pick)
        passwordCreate = EditText(this).apply { hint = "Strong photo password (share separately)"; inputType = 0x00000081 }
        root.addView(passwordCreate)
        expiry = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Expires in 1 hour", "Expires in 6 hours", "Expires in 24 hours")) }
        root.addView(expiry)
        root.addView(Button(this).apply { text = "Encrypt & create one-time link"; setOnClickListener { createShare() } })
        root.addView(TextView(this).apply { text = "Open a received share"; textSize = 18f; setPadding(0, 24, 0, 4) })
        codeInput = EditText(this).apply { hint = "Share code"; inputType = 0x00000001 }
        root.addView(codeInput)
        passwordInput = EditText(this).apply { hint = "Photo password"; inputType = 0x00000081 }
        root.addView(passwordInput)
        root.addView(Button(this).apply { text = "Open once"; setOnClickListener { openShare() } })
        image = ImageView(this).apply { adjustViewBounds = true; maxHeight = 1200; setPadding(0, 12, 0, 12) }
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Revoke my last share"; setOnClickListener { revokeShare() } })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun createShare() {
        val bytes = selectedBytes ?: return toast("Choose a photo first")
        val password = passwordCreate.text.toString()
        if (password.length < 12) return toast("Use at least 12 characters for the password")
        if (apiBase.contains("REPLACE_WITH")) return toast("Set your deployed Worker URL in MainActivity.kt first")
        status.text = "Encrypting photo and creating share…"
        val hours = when (expiry.selectedItemPosition) { 0 -> 1; 1 -> 6; else -> 24 }
        executor.execute {
            try {
                val random = SecureRandom()
                val contentKey = ByteArray(32).also(random::nextBytes)
                val photoIv = ByteArray(12).also(random::nextBytes)
                val photoCipher = aesGcm(Cipher.ENCRYPT_MODE, contentKey, photoIv, bytes)
                val salt = ByteArray(16).also(random::nextBytes)
                val wrapIv = ByteArray(12).also(random::nextBytes)
                val passwordKey = derivePasswordKey(password, salt)
                val wrappedKey = aesGcm(Cipher.ENCRYPT_MODE, passwordKey, wrapIv, contentKey)
                contentKey.fill(0); passwordKey.fill(0)
                val payload = JSONObject().apply {
                    put("ciphertextB64", b64(photoCipher)); put("saltB64", b64(salt)); put("wrapIvB64", b64(wrapIv))
                    put("wrappedKeyB64", b64(wrappedKey)); put("photoIvB64", b64(photoIv)); put("expiresHours", hours)
                }
                val response = request("/api/share", "POST", payload.toString())
                val id = response.getString("id")
                revokeToken = response.getString("revokeToken"); currentShareId = id
                runOnUiThread { status.text = "Share code: $id\nSend this code and send the password separately. The server will release the encrypted package once."; codeInput.setText(id) }
            } catch (e: Exception) { showError(e.message ?: "Share creation failed") }
        }
    }

    private fun openShare() {
        val id = codeInput.text.toString().trim()
        val password = passwordInput.text.toString()
        if (id.isBlank() || password.isBlank()) return toast("Enter share code and password")
        if (apiBase.contains("REPLACE_WITH")) return toast("Set your deployed Worker URL in MainActivity.kt first")
        image.setImageDrawable(null); status.text = "Consuming one-time share…"
        executor.execute {
            try {
                val response = request("/api/open", "POST", JSONObject().put("id", id).toString())
                val salt = unb64(response.getString("saltB64")); val wrapIv = unb64(response.getString("wrapIvB64"))
                val wrapped = unb64(response.getString("wrappedKeyB64")); val photoIv = unb64(response.getString("photoIvB64"))
                val ciphertext = unb64(response.getString("ciphertextB64"))
                val passwordKey = derivePasswordKey(password, salt)
                val contentKey = aesGcm(Cipher.DECRYPT_MODE, passwordKey, wrapIv, wrapped)
                passwordKey.fill(0)
                val plaintext = aesGcm(Cipher.DECRYPT_MODE, contentKey, photoIv, ciphertext)
                contentKey.fill(0)
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(plaintext, 0, plaintext.size, opts)
                var sample = 1
                while (opts.outWidth / sample > 1600 || opts.outHeight / sample > 1600) sample *= 2
                val decoded = BitmapFactory.decodeByteArray(plaintext, 0, plaintext.size, BitmapFactory.Options().apply { inSampleSize = sample })
                plaintext.fill(0)
                runOnUiThread { image.setImageBitmap(decoded); status.text = "Opened. This share has been consumed; do not leave this screen open." }
            } catch (e: Exception) { showError("Could not open share. It may already have been consumed, expired, or the password may be wrong. (${e.message ?: "error"})") }
        }
    }

    private fun revokeShare() {
        val id = currentShareId ?: return toast("No share created in this session")
        val token = revokeToken ?: return toast("No revocation token available")
        executor.execute {
            try {
                request("/api/share/$id", "DELETE", JSONObject().put("revokeToken", token).toString())
                runOnUiThread { status.text = "Share revoked." }
            } catch (e: Exception) { showError(e.message ?: "Revocation failed") }
        }
    }

    private fun derivePasswordKey(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 600_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    private fun aesGcm(mode: Int, key: ByteArray, iv: ByteArray, input: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(input)
    }

    private fun request(path: String, method: String, body: String): JSONObject {
        val conn = (URL(apiBase.trimEnd('/') + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method; conn.connectTimeout = 15000; conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true; conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw IllegalStateException("Server ${conn.responseCode}: $text")
        return JSONObject(text)
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.DEFAULT)
    private fun showError(message: String) { runOnUiThread { status.text = message } }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    override fun onDestroy() { image.setImageDrawable(null); selectedBytes?.fill(0); selectedBytes = null; executor.shutdownNow(); super.onDestroy() }
}
