package org.oncephoto.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.text.InputType
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : ComponentActivity() {
    private val apiBase = "https://script.google.com/macros/s/AKfycbzr1Gk42O3rmuhUfAjS9Iga-VhWKXzG9Ngd8wgSiMHICnHpSRKatPvRhjUVn6wpk7qBWw/exec"
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var codeInput: EditText
    private lateinit var ownerSecretInput: EditText
    private lateinit var expiry: Spinner
    private var selectedPhotos: List<Uri> = emptyList()
    private var pending: PendingBundle? = null
    private var lastBundleId: String? = null
    private var lastCode: String? = null
    private var viewerFiles: List<File> = emptyList()
    private var viewerIndex = 0
    private var viewerStartX = 0f
    private var viewerImage: ImageView? = null
    private var viewerCaption: TextView? = null
    private var viewerRoot: View? = null
    private var displayedBitmap: Bitmap? = null

    private data class PendingBundle(val uris: List<Uri>, val id: String, val key: ByteArray, val code: String, val expiresHours: Int, val ownerSecret: String, val totalBytes: Long)
    private data class PhotoInfo(val uri: Uri, val name: String, val size: Long)

    private val pickPhotos = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            selectedPhotos = uris
            val bytes = uris.sumOf { querySize(it).coerceAtLeast(0L) }
            status.text = "${uris.size} photos selected · ${formatBytes(bytes)} total. They will be encrypted locally into one .onephoto file."
        }
    }
    private val saveBundle = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val p = pending
        if (uri == null || p == null) {
            p?.key?.fill(0)
            if (p != null) executor.execute { try { val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE); request(JSONObject().put("action", "revoke").put("ownerSecret", p.ownerSecret).put("photoId", p.id).put("revokeToken", prefs.getString("lastRevokeToken", "")).toString()) } catch (_: Exception) {} }
            pending = null
            status.text = "Save cancelled. No photo bytes were uploaded; the unused share is being revoked."
            return@registerForActivityResult
        }
        executor.execute {
            try {
                contentResolver.openOutputStream(uri, "w").use { raw ->
                    if (raw == null) throw IOException("Could not create destination file")
                    val out = DataOutputStream(BufferedOutputStream(raw))
                    val idBytes = p.id.toByteArray(Charsets.UTF_8)
                    out.write(byteArrayOf(79, 78, 69, 80, 72, 49)) // ONEPH1
                    out.writeShort(idBytes.size); out.write(idBytes)
                    out.writeShort(p.uris.size)
                    val buffer = ByteArray(64 * 1024)
                    for (uriPhoto in p.uris) {
                        val info = photoInfo(uriPhoto)
                        val nameBytes = info.name.toByteArray(Charsets.UTF_8).take(1024).toByteArray()
                        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
                        out.writeShort(nameBytes.size); out.write(nameBytes)
                        out.writeLong(info.size.coerceAtLeast(0L)); out.writeByte(iv.size); out.write(iv)
                        out.writeLong(info.size.coerceAtLeast(0L) + 16L)
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(p.key, "AES"), GCMParameterSpec(128, iv))
                        contentResolver.openInputStream(uriPhoto).use { input ->
                            if (input == null) throw IOException("Cannot read ${info.name}")
                            var readTotal = 0L
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                readTotal += n
                                val encrypted = cipher.update(buffer, 0, n)
                                if (encrypted != null && encrypted.isNotEmpty()) { out.write(encrypted); encrypted.fill(0) }
                            }
                            if (info.size >= 0 && readTotal != info.size) throw IOException("File size changed while reading ${info.name}")
                        }
                        val finalBytes = cipher.doFinal()
                        out.write(finalBytes); finalBytes.fill(0)
                    }
                    buffer.fill(0); out.flush(); out.close()
                }
                lastBundleId = p.id; lastCode = p.code
                rememberCode(p.id, p.code)
                p.key.fill(0); pending = null
                runOnUiThread {
                    codeInput.setText(lastCode)
                    status.text = "Saved one encrypted .onephoto bundle (${p.uris.size} photos, ${formatBytes(p.totalBytes)} original data). Code: ${p.code}. Send the file and code separately. No photo bytes were uploaded."
                }
            } catch (e: Exception) {
                p.key.fill(0); pending = null
                showError("Could not create bundle: ${e.message ?: "unknown error"}")
            }
        }
    }
    private val pickBundle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) openBundle(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        lastBundleId = getSharedPreferences("oncephoto", MODE_PRIVATE).getString("lastBundleId", null)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 20, 24, 24) }
        root.addView(TextView(this).apply { text = "OncePhoto"; textSize = 30f; setTextColor(0xff172033.toInt()) })
        root.addView(TextView(this).apply { text = "Private photo bundles · local encryption · one-time access"; textSize = 14f })
        status = TextView(this).apply { text = "Select multiple photos to encrypt them into one .onephoto file."; setPadding(0, 18, 0, 16) }
        root.addView(status)
        root.addView(Button(this).apply { text = "Choose multiple photos"; setOnClickListener { pickPhotos.launch("image/*") } })
        ownerSecretInput = EditText(this).apply { hint = "Owner secret (Apps Script OWNER_SECRET)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; isSingleLine = true }
        root.addView(ownerSecretInput)
        expiry = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Code expires in 1 hour", "Code expires in 6 hours", "Code expires in 24 hours")) }
        root.addView(expiry)
        root.addView(Button(this).apply { text = "Encrypt bundle & save .onephoto"; setOnClickListener { beginCreate() } })
        root.addView(Button(this).apply { text = "Copy latest one-time code"; setOnClickListener { copyCode() } })
        root.addView(Button(this).apply { text = "Show active codes & file sizes"; setOnClickListener { listActive() } })
        root.addView(Button(this).apply { text = "Generate replacement code for last bundle"; setOnClickListener { generateNewCode() } })
        root.addView(Button(this).apply { text = "Revoke last bundle"; setOnClickListener { revokeLast() } })
        root.addView(TextView(this).apply { text = "Receive bundle"; textSize = 20f; setPadding(0, 22, 0, 4) })
        root.addView(Button(this).apply { text = "Choose received .onephoto file"; setOnClickListener { pickBundle.launch(arrayOf("*/*")) } })
        codeInput = EditText(this).apply { hint = "One-time code"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS; isSingleLine = true }
        root.addView(codeInput)
        root.addView(Button(this).apply { text = "Authenticate & view once"; setOnClickListener { val uri = receiveUri ?: return@setOnClickListener toast("Choose the received .onephoto file first"); openBundle(uri) } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private var receiveUri: Uri? = null
    private fun expiryHours() = when (expiry.selectedItemPosition) { 0 -> 1; 1 -> 6; else -> 24 }

    private fun beginCreate() {
        val uris = selectedPhotos
        if (uris.isEmpty()) return toast("Choose one or more photos first")
        val owner = ownerSecretInput.text.toString()
        if (owner.length < 32) return toast("Enter your Apps Script owner secret")
        val infos = try { uris.map { photoInfo(it) } } catch (e: Exception) { return toast("Cannot read selected photos: ${e.message}") }
        val total = infos.sumOf { it.size.coerceAtLeast(0L) }
        if (total <= 0) return toast("Could not determine the selected photos' total size")
        val hours = expiryHours()
        status.text = "Preparing a unique one-time code and local encryption key…"
        executor.execute {
            var key: ByteArray? = null
            try {
                val reg = request(JSONObject().put("action", "registerBundle").put("ownerSecret", owner).put("photoCount", uris.size).put("sizeBytes", estimateBundleSize(infos)).put("expiresHours", 720).toString())
                val id = reg.getString("photoId")
                val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE)
                val revokeToken = reg.getString("revokeToken")
                prefs.edit().putString("lastBundleId", id).putString("lastRevokeToken", revokeToken).apply()
                val codeResult = request(JSONObject().put("action", "newCode").put("ownerSecret", owner).put("photoId", id).put("codeExpiresHours", hours).toString())
                val code = codeResult.getString("code")
                key = ByteArray(32).also { SecureRandom().nextBytes(it) }
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                val wrapIv = ByteArray(12).also { SecureRandom().nextBytes(it) }
                val codeKey = deriveCodeKey(code.substringAfter('.'), salt)
                val wrapped = aesGcm(Cipher.ENCRYPT_MODE, codeKey, wrapIv, key!!)
                codeKey.fill(0)
                request(JSONObject().put("action", "setKeyWrap").put("ownerSecret", owner).put("photoId", id).put("saltB64", b64(salt)).put("wrapIvB64", b64(wrapIv)).put("wrappedKeyB64", b64(wrapped)).toString())
                wrapped.fill(0)
                pending = PendingBundle(uris, id, key!!, code, hours, owner, total)
                key = null
                lastBundleId = id; lastCode = code; rememberCode(id, code)
                runOnUiThread { status.text = "Code created. Choose where to save your encrypted bundle…"; saveBundle.launch("OncePhoto-$id.onephoto") }
            } catch (e: Exception) { key?.fill(0); showError("Could not prepare bundle: ${e.message ?: "error"}") }
        }
    }

    private fun openBundle(uri: Uri) {
        receiveUri = uri
        val code = codeInput.text.toString().trim()
        if (code.isBlank()) return toast("Enter the one-time code")
        clearViewer()
        status.text = "Checking bundle and authenticating online…"
        executor.execute {
            val tempFiles = mutableListOf<File>()
            var key: ByteArray? = null
            try {
                val raw = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open selected file")
                val input = DataInputStream(BufferedInputStream(raw))
                val magic = ByteArray(6); input.readFully(magic)
                if (!magic.contentEquals(byteArrayOf(79, 78, 69, 80, 72, 49))) throw IOException("Not a valid .onephoto bundle")
                val idLen = input.readUnsignedShort(); if (idLen !in 1..128) throw IOException("Invalid bundle header")
                val idBytes = ByteArray(idLen); input.readFully(idBytes)
                val id = String(idBytes, Charsets.UTF_8)
                if (code.substringBefore('.', "") != id) throw IOException("This code belongs to a different .onephoto file")
                val auth = request(JSONObject().put("action", "open").put("code", code).toString())
                if (auth.getString("photoId") != id) throw IOException("Server returned a different bundle")
                val salt = unb64(auth.getString("saltB64"))
                val wrapIv = unb64(auth.getString("wrapIvB64"))
                val wrappedKey = unb64(auth.getString("wrappedKeyB64"))
                val codeKey = deriveCodeKey(code.substringAfter('.'), salt)
                key = aesGcm(Cipher.DECRYPT_MODE, codeKey, wrapIv, wrappedKey)
                codeKey.fill(0); wrappedKey.fill(0)
                val count = input.readUnsignedShort(); if (count !in 1..100) throw IOException("Invalid photo count")
                val buffer = ByteArray(64 * 1024)
                repeat(count) { index ->
                    val nameLen = input.readUnsignedShort(); if (nameLen !in 1..1024) throw IOException("Invalid photo name")
                    val nameBytes = ByteArray(nameLen); input.readFully(nameBytes)
                    val plainSize = input.readLong(); if (plainSize !in 1..(1024L * 1024L * 1024L)) throw IOException("Invalid photo size")
                    val ivLen = input.readUnsignedByte(); if (ivLen != 12) throw IOException("Invalid photo IV")
                    val iv = ByteArray(ivLen); input.readFully(iv)
                    val cipherSize = input.readLong(); if (cipherSize != plainSize + 16L) throw IOException("Invalid encrypted size")
                    val outFile = File.createTempFile("oncephoto-$index-", ".img", cacheDir)
                    tempFiles.add(outFile)
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
                    FileOutputStream(outFile).use { out ->
                        var remaining = cipherSize
                        while (remaining > 0) {
                            val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                            if (n < 0) throw EOFException("Encrypted bundle is truncated")
                            remaining -= n
                            val decoded = cipher.update(buffer, 0, n)
                            if (decoded != null && decoded.isNotEmpty()) { out.write(decoded); decoded.fill(0) }
                        }
                        val final = cipher.doFinal(); out.write(final); final.fill(0)
                    }
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(outFile.absolutePath, bounds)
                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Photo ${index + 1} is not a supported image")
                }
                buffer.fill(0); input.close()
                runOnUiThread {
                    viewerFiles = tempFiles.toList(); viewerIndex = 0
                    showFullScreenViewer()
                    status.text = "Code consumed. ${viewerFiles.size} photo(s) opened. Close the viewer to delete temporary decrypted files."
                }
            } catch (e: Exception) {
                tempFiles.forEach { it.delete() }
                showError("Could not open bundle: ${e.message ?: "error"}. If the code was consumed, ask the sender to issue a new one.")
            } finally { key?.fill(0) }
        }
    }

    private fun showFullScreenViewer() {
        val root = android.widget.FrameLayout(this)
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xff000000.toInt()) }
        val caption = TextView(this).apply { setTextColor(-1); textSize = 14f; gravity = Gravity.CENTER; setPadding(8, 12, 8, 16); setBackgroundColor(0x88000000.toInt()) }
        root.addView(img, android.widget.FrameLayout.LayoutParams(-1, -1))
        root.addView(caption, android.widget.FrameLayout.LayoutParams(-1, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { viewerStartX = event.x; true }
                MotionEvent.ACTION_UP -> { val dx = event.x - viewerStartX; if (kotlin.math.abs(dx) > 80) { if (dx < 0) showViewerIndex(viewerIndex + 1) else showViewerIndex(viewerIndex - 1) } else if (event.y < root.height * 0.8f) closeViewer(); true }
                else -> true
            }
        }
        viewerImage = img; viewerCaption = caption; viewerRoot = root
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(root)
        showViewerIndex(0)
    }

    private fun showViewerIndex(index: Int) {
        if (viewerFiles.isEmpty()) return closeViewer()
        viewerIndex = ((index % viewerFiles.size) + viewerFiles.size) % viewerFiles.size
        displayedBitmap?.recycle(); displayedBitmap = null
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(viewerFiles[viewerIndex].absolutePath, opts)
        var sample = 1
        while (opts.outWidth / sample > 2400 || opts.outHeight / sample > 2400) sample *= 2
        displayedBitmap = BitmapFactory.decodeFile(viewerFiles[viewerIndex].absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        viewerImage?.setImageBitmap(displayedBitmap)
        viewerCaption?.text = "Photo ${viewerIndex + 1} of ${viewerFiles.size} · swipe to navigate · tap to close"
    }

    private fun closeViewer() {
        displayedBitmap?.recycle(); displayedBitmap = null
        viewerImage?.setImageDrawable(null)
        viewerFiles.forEach { try { it.delete() } catch (_: Exception) {} }; viewerFiles = emptyList()
        viewerImage = null; viewerCaption = null; viewerRoot = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        buildUi()
        status.text = "Viewer closed. Temporary decrypted files were deleted."
    }

    private fun clearViewer() {
        displayedBitmap?.recycle(); displayedBitmap = null
        viewerFiles.forEach { try { it.delete() } catch (_: Exception) {} }; viewerFiles = emptyList()
    }

    private fun listActive() {
        val owner = ownerSecretInput.text.toString()
        if (owner.length < 32) return toast("Enter your owner secret")
        status.text = "Loading active shares…"
        executor.execute {
            try {
                val r = request(JSONObject().put("action", "listActive").put("ownerSecret", owner).toString())
                val rows = r.getJSONArray("shares")
                val message = if (rows.length() == 0) "No active codes." else buildString {
                    append("ACTIVE ONE-TIME CODES\n\n")
                    for (i in 0 until rows.length()) {
                        val item = rows.getJSONObject(i); val id = item.getString("photoId")
                        val code = rememberedCode(id)
                        append("File: ").append(id.take(8)).append("…\n")
                        append("Size: ").append(formatBytes(item.optLong("sizeBytes"))).append(" · Photos: ").append(item.optInt("photoCount")).append("\n")
                        append("Code: ").append(code ?: "Code not saved on this device; generate a replacement").append("\n")
                        append("Expires: ").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(item.optLong("codeExpiresAt")))).append("\n\n")
                    }
                }
                runOnUiThread { status.text = message }
            } catch (e: Exception) { showError("Could not list shares: ${e.message ?: "error"}") }
        }
    }

    private fun generateNewCode() {
        val id = lastBundleId ?: getSharedPreferences("oncephoto", MODE_PRIVATE).getString("lastBundleId", null) ?: return toast("Create a bundle first")
        val owner = ownerSecretInput.text.toString(); if (owner.length < 32) return toast("Enter your owner secret")
        executor.execute {
            try {
                val r = request(JSONObject().put("action", "newCode").put("ownerSecret", owner).put("photoId", id).put("codeExpiresHours", expiryHours()).toString())
                lastCode = r.getString("code"); rememberCode(id, lastCode!!)
                runOnUiThread { codeInput.setText(lastCode); status.text = "Replacement code generated. The previous code for this file is invalid." }
            } catch (e: Exception) { showError(e.message ?: "Could not generate code") }
        }
    }

    private fun revokeLast() {
        val prefs = getSharedPreferences("oncephoto", MODE_PRIVATE)
        val id = lastBundleId ?: prefs.getString("lastBundleId", null) ?: return toast("No bundle found")
        val token = prefs.getString("lastRevokeToken", null) ?: return toast("Revocation token unavailable on this device")
        val owner = ownerSecretInput.text.toString(); if (owner.length < 32) return toast("Enter your owner secret")
        executor.execute {
            try {
                request(JSONObject().put("action", "revoke").put("ownerSecret", owner).put("photoId", id).put("revokeToken", token).toString())
                forgetCode(id)
                runOnUiThread { status.text = "Bundle revoked. Its active code will no longer authenticate." }
            } catch (e: Exception) { showError(e.message ?: "Revocation failed") }
        }
    }

    private fun copyCode() {
        val code = lastCode ?: codeInput.text.toString().trim().takeIf { it.contains('.') } ?: return toast("Generate a code first")
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("OncePhoto code", code))
        toast("One-time code copied")
    }

    private fun photoInfo(uri: Uri): PhotoInfo {
        var name = "photo.jpg"; var size = -1L
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) { val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE); if (ni >= 0) name = c.getString(ni) ?: name; if (si >= 0 && !c.isNull(si)) size = c.getLong(si) }
        }
        if (size < 0) size = querySize(uri)
        if (size <= 0) throw IOException("Could not determine file size for $name")
        return PhotoInfo(uri, name, size)
    }
    private fun querySize(uri: Uri): Long = try { photoInfoShallow(uri) } catch (_: Exception) { -1L }
    private fun photoInfoShallow(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.SIZE); if (i >= 0 && !c.isNull(i)) return c.getLong(i) } }
        return -1L
    }
    private fun estimateBundleSize(infos: List<PhotoInfo>): Long = 6L + 2 + 32 + 2 + infos.sumOf { it.size + 16L + 2 + it.name.toByteArray(Charsets.UTF_8).size + 8 + 1 + 12 + 8 }
    private fun rememberCode(id: String, code: String) { val p = getSharedPreferences("oncephoto", MODE_PRIVATE); val all = try { JSONObject(p.getString("codes", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }; all.put(id, code); p.edit().putString("codes", all.toString()).apply() }
    private fun rememberedCode(id: String): String? = try { JSONObject(getSharedPreferences("oncephoto", MODE_PRIVATE).getString("codes", "{}") ?: "{}").optString(id).takeIf { it.isNotBlank() } } catch (_: Exception) { null }
    private fun forgetCode(id: String) { val p = getSharedPreferences("oncephoto", MODE_PRIVATE); val all = try { JSONObject(p.getString("codes", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }; all.remove(id); p.edit().putString("codes", all.toString()).apply() }
    private fun formatBytes(n: Long): String = when { n < 0 -> "Unknown size"; n < 1024 -> "$n B"; n < 1024*1024 -> "%.1f KB".format(n / 1024.0); n < 1024L*1024*1024 -> "%.1f MB".format(n / (1024.0*1024)); else -> "%.2f GB".format(n / (1024.0*1024*1024)) }
    private fun deriveCodeKey(token: String, salt: ByteArray): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(token.toCharArray(), salt, 100_000, 256)
        return try { javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }
    private fun aesGcm(mode: Int, key: ByteArray, iv: ByteArray, input: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(input)
    }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.DEFAULT)
    private fun request(body: String): JSONObject {
        val conn = URL(apiBase).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 90000; conn.instanceFollowRedirects = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8"); conn.setRequestProperty("Cache-Control", "no-store"); conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode; val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val result = try { JSONObject(text) } catch (_: Exception) { throw IOException("Server returned non-JSON (HTTP $code)") }
            if (code !in 200..299 || !result.optBoolean("ok", false)) throw IOException(result.optString("error", "Server error HTTP $code"))
            return result
        } finally { conn.disconnect() }
    }
    private fun showError(message: String) { runOnUiThread { status.text = message } }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    override fun onBackPressed() { if (viewerRoot != null) closeViewer() else super.onBackPressed() }
    override fun onStop() { if (viewerRoot != null) closeViewer(); super.onStop() }
    override fun onDestroy() { clearViewer(); pending?.key?.fill(0); executor.shutdownNow(); super.onDestroy() }
}

