const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store, max-age=0",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "POST, DELETE, OPTIONS",
  "access-control-allow-headers": "content-type, x-owner-secret",
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
const randomHex = (length = 32) => Array.from(crypto.getRandomValues(new Uint8Array(length / 2)), b => b.toString(16).padStart(2, "0")).join("");
const sha256Hex = async (value) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))), b => b.toString(16).padStart(2, "0")).join("");
const validId = value => typeof value === "string" && /^[a-f0-9]{32}$/.test(value);
const validCode = value => typeof value === "string" && /^[a-f0-9]{32}\.[a-f0-9]{32}$/.test(value);

async function ownerAuthorized(request, env) {
  const supplied = request.headers.get("x-owner-secret") || "";
  const expected = env.OWNER_SECRET || "";
  if (expected.length < 32 || supplied.length !== expected.length) return false;
  // Constant-time comparison for equal-length UTF-8 values.
  const a = new TextEncoder().encode(supplied), b = new TextEncoder().encode(expected);
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

function photoStub(env, id) { return env.PHOTOS.get(env.PHOTOS.idFromName(id)); }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: JSON_HEADERS });
    try {
      if (url.pathname === "/api/health" && request.method === "GET") {
        return json({ ok: true, service: "oncephoto", ownerSecretConfigured: Boolean(env.OWNER_SECRET && env.OWNER_SECRET.length >= 32) });
      }

      // Uploads encrypted bytes only. The password and plaintext never leave the phone.
      if (url.pathname === "/api/photos" && request.method === "POST") {
        if (!await ownerAuthorized(request, env)) return json({ error: "Owner authentication failed. Configure OWNER_SECRET and enter it in the app." }, 401);
        const body = await request.json();
        for (const key of ["ciphertextB64", "saltB64", "wrapIvB64", "wrappedKeyB64", "photoIvB64"]) {
          if (typeof body[key] !== "string" || body[key].length === 0) return json({ error: `Missing ${key}` }, 400);
        }
        const hours = Number(body.expiresHours);
        if (![1, 6, 24].includes(hours)) return json({ error: "expiresHours must be 1, 6, or 24" }, 400);
        let binary;
        try { binary = Uint8Array.from(atob(body.ciphertextB64), c => c.charCodeAt(0)); }
        catch { return json({ error: "Invalid ciphertext encoding" }, 400); }
        if (binary.length < 17 || binary.length > 8 * 1024 * 1024 + 16) return json({ error: "Encrypted image must be 8 MB or smaller" }, 413);
        const id = randomHex(32);
        const expiresAt = Date.now() + hours * 3600000;
        await env.CIPHERTEXT.put(id, binary, { httpMetadata: { contentType: "application/octet-stream" }, customMetadata: { expiresAt: String(expiresAt) } });
        const meta = {
          id, saltB64: body.saltB64, wrapIvB64: body.wrapIvB64,
          wrappedKeyB64: body.wrappedKeyB64, photoIvB64: body.photoIvB64,
          expiresAt, createdAt: Date.now()
        };
        const stored = await photoStub(env, id).fetch("https://photo-store/create", { method: "POST", body: JSON.stringify(meta) });
        if (!stored.ok) { await env.CIPHERTEXT.delete(id); return json({ error: "Could not store photo metadata" }, 500); }
        return json({ photoId: id, expiresAt });
      }

      // Owner rotates the one active code for a photo. A newly issued code invalidates every older code.
      const codeMatch = url.pathname.match(/^\/api\/photos\/([a-f0-9]{32})\/codes$/);
      if (codeMatch && request.method === "POST") {
        if (!await ownerAuthorized(request, env)) return json({ error: "Owner authentication failed" }, 401);
        const photoId = codeMatch[1];
        const body = await request.json().catch(() => ({}));
        const stub = photoStub(env, photoId);
        const token = randomHex(32);
        const result = await stub.fetch("https://photo-store/issue-code", { method: "POST", body: JSON.stringify({ tokenHash: await sha256Hex(token), expiresHours: body.expiresHours }) });
        if (!result.ok) return json({ error: "Photo not found, expired, or already unavailable" }, result.status);
        const data = await result.json();
        return json({ code: `${photoId}.${token}`, expiresAt: data.expiresAt, note: "This is the only active code for this photo. Generating another code invalidates this one." });
      }

      // Every opening requires a live, unused code and internet access. Consumption happens atomically in the PhotoStore DO.
      if (url.pathname === "/api/open" && request.method === "POST") {
        const body = await request.json();
        if (!validCode(body.code)) return json({ error: "Invalid code format" }, 400);
        const [photoId, token] = body.code.split(".");
        const stub = photoStub(env, photoId);
        const consumed = await stub.fetch("https://photo-store/consume-code", { method: "POST", body: JSON.stringify({ tokenHash: await sha256Hex(token) }) });
        if (!consumed.ok) return json({ error: "Code is invalid, expired, revoked, or already used. Ask the sender for a new code." }, 410);
        const meta = await consumed.json();
        const object = await env.CIPHERTEXT.get(photoId);
        if (!object) return json({ error: "Encrypted photo is unavailable or expired" }, 410);
        const bytes = new Uint8Array(await object.arrayBuffer());
        let binary = "";
        for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        return json({ ...meta, ciphertextB64: btoa(binary) });
      }

      const revokeMatch = url.pathname.match(/^\/api\/photos\/([a-f0-9]{32})$/);
      if (revokeMatch && request.method === "DELETE") {
        if (!await ownerAuthorized(request, env)) return json({ error: "Owner authentication failed" }, 401);
        const id = revokeMatch[1];
        const result = await photoStub(env, id).fetch("https://photo-store/revoke", { method: "POST" });
        await env.CIPHERTEXT.delete(id);
        if (!result.ok) return json({ error: "Photo not found" }, 404);
        return json({ revoked: true });
      }
      return json({ error: "Not found" }, 404);
    } catch (error) {
      return json({ error: "Request failed", detail: String(error?.message || error) }, 500);
    }
  }
};

// Hourly cleanup removes expired encrypted blobs from R2.
export async function scheduled(_controller, env, _ctx) {
  let cursor;
  do {
    const page = await env.CIPHERTEXT.list({ cursor, limit: 1000 });
    const expired = page.objects.filter(obj => {
      const at = Number(obj.customMetadata?.expiresAt || 0);
      return at > 0 && at <= Date.now();
    });
    if (expired.length) await env.CIPHERTEXT.delete(expired.map(obj => obj.key));
    cursor = page.truncated ? page.cursor : undefined;
  } while (cursor);
}

// Durable Object serializes code issuance and consumption for each photo.
export class PhotoStore {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === "/create" && request.method === "POST") {
      const meta = await request.json();
      if (await this.ctx.storage.get("meta")) return new Response("exists", { status: 409 });
      await this.ctx.storage.put("meta", meta);
      await this.ctx.storage.put("used", false);
      return new Response("ok");
    }
    if (path === "/issue-code" && request.method === "POST") {
      const { tokenHash, expiresHours } = await request.json();
      const meta = await this.ctx.storage.get("meta");
      if (!meta || meta.expiresAt <= Date.now() || await this.ctx.storage.get("revoked")) return new Response("gone", { status: 410 });
      const hours = Number(expiresHours ?? 1);
      if (![1, 6, 24].includes(hours)) return new Response("invalid expiry", { status: 400 });
      const expiresAt = Math.min(meta.expiresAt, Date.now() + hours * 3600000);
      // Rotating this hash immediately invalidates the previous unused code.
      await this.ctx.storage.put("activeTokenHash", tokenHash);
      await this.ctx.storage.put("codeExpiresAt", expiresAt);
      await this.ctx.storage.put("used", false);
      return Response.json({ expiresAt });
    }
    if (path === "/consume-code" && request.method === "POST") {
      const { tokenHash } = await request.json();
      const meta = await this.ctx.storage.get("meta");
      const active = await this.ctx.storage.get("activeTokenHash");
      const codeExpiresAt = await this.ctx.storage.get("codeExpiresAt");
      if (!meta || !active || active !== tokenHash || !codeExpiresAt || codeExpiresAt <= Date.now() || meta.expiresAt <= Date.now() || await this.ctx.storage.get("used") || await this.ctx.storage.get("revoked")) {
        return new Response("gone", { status: 410 });
      }
      // Consume before returning any decryption material. One photo can be viewed once per upload.
      await this.ctx.storage.delete("activeTokenHash");
      await this.ctx.storage.delete("codeExpiresAt");
      await this.ctx.storage.put("used", true);
      const { id, saltB64, wrapIvB64, wrappedKeyB64, photoIvB64, expiresAt } = meta;
      return Response.json({ id, saltB64, wrapIvB64, wrappedKeyB64, photoIvB64, expiresAt });
    }
    if (path === "/revoke" && request.method === "POST") {
      const meta = await this.ctx.storage.get("meta");
      if (!meta) return new Response("gone", { status: 404 });
      await this.ctx.storage.put("revoked", true);
      await this.ctx.storage.delete("activeTokenHash");
      await this.ctx.storage.delete("codeExpiresAt");
      await this.ctx.storage.delete("meta");
      return new Response("ok");
    }
    return new Response("not found", { status: 404 });
  }
}

// Kept only to preserve compatibility with an earlier deployed migration.
export class ShareStore {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }
  async fetch() { return new Response("Legacy endpoint disabled", { status: 410 }); }
}
