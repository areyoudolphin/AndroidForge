# OncePhoto — encrypted one-time photo access (prototype)

OncePhoto is an Android prototype with a Cloudflare Worker + R2 + Durable Objects backend. It encrypts image bytes on the Android device, uploads only ciphertext, and requires an online one-time authorization code before each viewing session.

**This is not audited security software. Test with non-sensitive images only.** A hostile recipient can still capture the display externally, use a compromised/rooted device, instrument the app, or retain secrets from memory/network traffic. `FLAG_SECURE` blocks normal Android screenshots and many screen-recording paths, not every possible capture. No app can guarantee that a recipient cannot copy plaintext once they are authorized to view it.

## Behavior

- AES-256-GCM encrypts the photo on the sender's phone. A password-derived key (PBKDF2-HMAC-SHA256, 600,000 iterations) wraps the random content key. The photo password is never sent to the server.
- The server stores only encrypted image bytes and key-wrapping metadata. It does not receive the plaintext photo or photo password.
- Opening requires internet. If the server cannot authorize the code, the app refuses to open the photo.
- A code is consumed atomically before the encrypted package is returned. Each code can be used once.
- The owner can generate a fresh code for the same photo. Issuing a new code invalidates any previous unused code. A previously used code remains consumed.
- Photo expiry is 1, 6, or 24 hours. Expired R2 objects are cleaned by an hourly scheduled Worker task.
- The owner secret is a Cloudflare Worker secret, entered in the sender UI. It is not compiled into the APK. Never share it with the recipient or commit it to Git.

## 1. Deploy the Cloudflare backend

You need a Cloudflare account. No always-on computer/server is needed; Workers runs on demand. Cloudflare account features, limits, and pricing can change, so check them before use.

In Termux, from the extracted project directory:

```sh
cd oncephoto/worker
npm install
npx wrangler login
npx wrangler r2 bucket create oncephoto-ciphertext
```

Create a long random owner secret (at least 32 characters). For example, generate one locally:

```sh
openssl rand -hex 32
```

Copy the output somewhere private. Then set it as a Cloudflare secret (Wrangler prompts you to paste it):

```sh
npx wrangler secret put OWNER_SECRET
```

Deploy:

```sh
npx wrangler deploy
```

Wrangler will create the Durable Object migration resources on deployment. If it reports that R2 is not enabled, enable R2 in your Cloudflare dashboard and retry. Do not put the owner secret in `wrangler.toml`, Kotlin source, GitHub, or this README.

After deployment, copy the Worker URL, such as `https://oncephoto-api.YOUR-SUBDOMAIN.workers.dev`.

## 2. Set the Worker URL in Android

Open `app/src/main/java/org/oncephoto/app/MainActivity.kt` and replace:

```kotlin
private val apiBase = "https://REPLACE_WITH_YOUR_WORKER.workers.dev"
```

with your actual Worker URL. Keep `https://`. Rebuild the APK after changing it.

## 3. Build the APK with GitHub Actions

1. Upload the project to your GitHub repository (include `.github/workflows/android.yml`).
2. Open the repository's **Actions** tab.
3. Run **Build OncePhoto APK** or push a commit to `main`.
4. On a successful run, download the `oncephoto-debug-apk` artifact and extract `app-debug.apk`.

The workflow uses a hosted Linux runner; no Android Studio or build server is needed on your phone. The first build may fail if a dependency or SDK download is unavailable; inspect the first failing step's logs.

## 4. Send and view a photo

### Sender
1. Open OncePhoto while online.
2. Choose a photo (maximum 8 MB) and enter a strong photo password of at least 12 characters.
3. Enter the owner secret you configured as `OWNER_SECRET`.
4. Choose an expiry and tap **Encrypt & upload photo**.
5. Copy/send the one-time code to the recipient. Send the photo password through a different channel.
6. To allow another view, enter the owner secret again and tap **Generate new one-time code**. This invalidates the prior unused code. A code is consumed when the recipient attempts to open it, even if the password is mistyped; generate a new code in that case.
7. **Revoke last photo** disables access and deletes the encrypted object from R2.

Keep the photo ID displayed after creation. The app remembers the most recent photo ID on the sender device; if app data is cleared, you will need the photo ID to generate new codes, so save it privately.

### Recipient
1. Install the APK and connect to the internet.
2. Enter the one-time code and photo password.
3. Tap **Authenticate & view once**. The server consumes the code before returning the encrypted package.
4. Close the image with **Close photo now** or leave the app; the app clears its displayed bitmap when the activity stops.

## API endpoints

- `GET /api/health` — basic service status (does not expose secrets).
- `POST /api/photos` — owner-authenticated upload of encrypted image bytes and key-wrapping metadata.
- `POST /api/photos/:photoId/codes` — owner-authenticated generation/rotation of a one-time code.
- `POST /api/open` — consumes a code once and returns encrypted bytes plus wrapping metadata.
- `DELETE /api/photos/:photoId` — owner-authenticated revocation and encrypted-object deletion.

## Important limits and residual risks

- One-time use is enforced by the server for each code and persists through recipient app-data clearing because the server tracks code use. The owner can issue another code.
- This does not prevent a technically capable recipient from saving the response/ciphertext and extracting the wrapped key, instrumenting the app, or capturing the decrypted image. A password plus a retained full encrypted response may permit later decryption outside the app. This architecture raises the barrier but cannot guarantee no export against a hostile device owner.
- The first code is consumed before password verification. A typo requires the sender to issue a fresh code.
- Owner secret is a shared bearer credential. Anyone who learns it can issue codes or revoke photos. Keep it private; rotate it with `npx wrangler secret put OWNER_SECRET` if exposed.
- Review Cloudflare R2/Workers/Durable Objects usage limits and privacy terms before real use. This project has not undergone an independent security audit.
